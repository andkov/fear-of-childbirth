

map <- function (data, corkind, display) {

# Velicer's MAP test -- takes raw data or a correlation matrix

nvars  <- ncol(data)

# determine whether data is a correlation matrix
if ( nrow(data) == ncol(data) ) {
if ( max(diag(data)) == 1 & min(diag(data)) == 1 ) {
datakind = 'correlations'}} else{ datakind = 'notcorrels'}

if (datakind == 'correlations') { rdata <- data }

if (datakind == 'notcorrels') {
ncases <- nrow(data)
# correlation matrix
if (corkind=='pearson')     { rdata <- cor(data, method="pearson") }
if (corkind=='kendall')     { rdata <- cor(data, method="kendall") }
if (corkind=='spearman')    { rdata <- cor(data, method="spearman") }
if (corkind=='polychoric')  { rdata <- polychoric(data)
if ( min(eigen(rdata) $values) < 0 ) { rdata <- smoothing(rdata) } }
}

eigval <- diag(svd(rdata) $d)
eigvect <- svd(rdata) $u
v <- svd(rdata) $v

loadings <- eigvect %*% sqrt(eigval)

fmfm4  <- t(rbind( (0:(nvars-1)), (0:(nvars-1)), (0:(nvars-1)) ))
fmfm4[1,2] <- (sum(sum(rdata^2))-nvars)/(nvars*(nvars-1))
fmfm4[1,3] <- (sum(sum(rdata^4))-nvars)/(nvars*(nvars-1))

for (m in 1:(nvars - 1)) {
a <- loadings[,1:m]
partcov <- as.matrix( rdata - (a %*% t(a)))
d <- diag (  (1 / sqrt(diag(partcov)))  )
pr <- d %*% partcov %*% d
fmfm4[m+1,2]  <- (sum(sum(pr^2))-nvars)/(nvars*(nvars-1))
fmfm4[m+1,3] <- (sum(sum(pr^4))-nvars)/(nvars*(nvars-1))
}

# identifying the smallest fm values & their locations
nfMAP   <- which.min(fmfm4[,2]) - 1
nfMAP4  <- which.min(fmfm4[,3]) - 1

dimnames(fmfm4) <-list(rep("", dim(fmfm4)[1]))
colnames(fmfm4) <- c("root","  Avg.Corr.Sq.","  Avg.Corr.power4")

evals <- cbind( 1:nvars, (diag(eigval)) )
dimnames(evals) <-list(rep("", dim(evals)[1]))
colnames(evals) <- c("root"," eigenvalue")

if (display == 'yes') {cat("\nVelicer's Minimum Average Partial Test \n")

if (datakind == 'correlations') { cat("\n\n The entered data is a correlation matrix.") }

if (datakind == 'notcorrels') {
cat("\nNumber of cases in the data file =       ", ncases)
cat("\nNumber of variables in the data file =   ", nvars)
# cat("\n\nSummary statistics for the data file:\n\n")
# print(summary(data))

# specification notices
if (corkind=='pearson')    {cat("\nCorrelations to be Analyzed: Pearson")}
if (corkind=='kendall')    {cat("\nCorrelations to be Analyzed: Kendall")}
if (corkind=='spearman')   {cat("\nCorrelations to be Analyzed: Spearman")}
if (corkind=='polychoric') {cat("\nCorrelations to be Analyzed: Polychoric")}
}

cat("\n\n\nEigenvalues:\n\n")
print(round(evals,5))

cat("\n\nVelicer's Average Squared Correlations\n\n")
print(round(fmfm4,5))

cat("\n\nThe smallest average squared correlation is      ", round(min(fmfm4[,2]),5))
cat("\n\nThe smallest average 4rth power correlation is   ", round(min(fmfm4[,3]),5))

# rownames(nfMAP) <- c(" ")  
cat("\n\nThe Number of Factors According to the Original (1976) MAP Test is =  ", nfMAP,  labels = NULL)
cat("\n\nThe Number of Factors According to the Revised  (2000) MAP Test is =  ", nfMAP4, labels = NULL, "\n\n")
}

mapOutput <- list( eigenvalues=evals, avgsqrs=fmfm4, nfMAP=nfMAP, nfMAP4=nfMAP4  )

return(invisible(mapOutput))

cat("\n\n")

}
