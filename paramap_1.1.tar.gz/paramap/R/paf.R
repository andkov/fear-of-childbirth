

# CFA / PAF  (Bernstein p 189; smc = from Bernstein p 104)

paf <- function (data, corkind, nfactors, iterpaf, rotate, ppower, display ) {

cnoms <- colnames(data) # get colnames

# determine whether data is a correlation matrix
if ( nrow(data) == ncol(data) ) {
if ( max(diag(data)) == 1 & min(diag(data)) == 1 ) {
datakind = 'correlations'}} else{ datakind = 'notcorrels'}

if (datakind == 'correlations') { cormat <- data }

if (datakind == 'notcorrels') {
Ncases <- nrow(data)
if (corkind=='pearson')     { cormat <- cor(data, method="pearson");  ctype <- 'Pearson'}
if (corkind=='kendall')     { cormat <- cor(data, method="kendall");  ctype <- 'Kendall' }
if (corkind=='spearman')    { cormat <- cor(data, method="spearman"); ctype <- 'Spearman' }
if (corkind=='polychoric')  { cormat <- polychoric(data);             ctype <- 'Polychoric'
if ( min(eigen(cormat) $values) < 0 ) { cormat <- smoothing(cormat) } }
}

converge  <- .001
rpaf <- as.matrix(cormat)
smc <- 1 - (1 / diag(solve(rpaf)) )
for (iter in 1:(iterpaf + 1)) {

diag(rpaf) <- smc # putting smcs on the main diagonal of r

eigval <-  diag((eigen(rpaf) $values))
# substituting zero for negative eigenvalues
for (luper in 1:nrow(eigval)) {
if ( eigval[luper,luper] < 0 ) { eigval[luper,luper] <- 0 }}

eigvect <- eigen(rpaf) $vectors

if (nfactors == 1) {
loadings <- eigvect[,1:nfactors] * sqrt(eigval[1:nfactors,1:nfactors])
communal <- loadings^2
}else {
loadings <- eigvect[,1:nfactors] %*% sqrt(eigval[1:nfactors,1:nfactors])
communal <- rowSums(loadings^2) }

if ( max(max(abs(communal-smc))) < converge) { break }
if ( max(max(abs(communal-smc))) >= converge  & iter < iterpaf) { smc <- communal }

}
loadings <- as.matrix(loadings)
rownames(loadings) <- cnoms
colnames(loadings) <- cbind(  (matrix( ("Factor"),1,ncol(loadings) )))

evalpaf  <-  cbind(diag(eigval))
rownames(evalpaf) <- 1:nrow(evalpaf)
colnames(evalpaf) <- "Eigenvalues"

if (rotate=='none')  { pafOutput <- list( eigenvalues=evalpaf, loadings=loadings ) }
if (rotate=='promax' | rotate=='varimax') {
if (ncol(loadings)==1) { loadingsROT <- loadings
pafOutput <- list( eigenvalues=evalpaf, loadingsNOROT=loadings ) } 
if (ncol(loadings) > 1) {
if (rotate=='varimax') { loadingsROT <- varimax(loadings,display='no')
pafOutput <- list( eigenvalues=evalpaf, loadingsNOROT=loadings, loadingsROT=loadingsROT )  } 
if (rotate=='promax')  { loadingsLIST <- promax(loadings,ppower,display='no')
pafOutput <- list( eigenvalues=evalpaf, structure=loadingsLIST$structure, pattern=loadingsLIST$pattern, correls=loadingsLIST$correls ) }
}}

if (display == 'yes') {
cat("\n\nPrincipal Axis Factor Analysis\n\n")
cat("\nSpecified kind of correlations for this analysis: ", ctype, "\n\n")
if ( max(max(abs(communal-smc))) < converge) {
cat("\nPAF converged in iterations = ", iter, "\n\n")	
print(round(evalpaf,2))
# cat("\n\nCommunalities: \n")
# print(round(communal,2))
cat("\nUnrotated PAF Loadings:\n\n")
print(round(cbind(loadings, communal),2))
} else { cat("\nPAF did not converge in the following number of iterations:  ", (iter-1))
}
if (ncol(loadings)==1) { cat("\n\nNo rotation because there is only one factor\n\n") }
if (ncol(loadings) > 1) {
if (rotate=='none')    {cat("\n\nRotation Procedure:  No Rotation")}
if (rotate=='varimax') {cat("\n\nVarimax Rotated Loadings:\n\n"); print(round(loadingsROT,2));cat("\n\n")}
if (rotate=='promax')  { 
cat("\n\nPromax Rotation Structure Matrix:\n\n");    print(round(loadingsLIST$structure,2));cat("\n")
cat("\n\nPromax Rotation Pattern Matrix:\n\n");      print(round(loadingsLIST$pattern,2));cat("\n")
cat("\n\nPromax Rotation Factor Correlations:\n\n"); print(round(loadingsLIST$correls,2));cat("\n\n")
}}}

return(invisible(pafOutput))

}



