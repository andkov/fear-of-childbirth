varimax <- function (loadings, display) {

# VARIMAX
# Marcus, 1993, in Reyment & Joreskog, 
# Applied Factor Analysis in the Natural Sciences, CUP.

# This procedure follows algorithm as spelled out in
# Harman (1960) in Chapter 14, section 4.  To run the
# program - the loadings are put in an array called
# loadings.  Type return to continue processing.
# The notation follows Harman.  

if (is.list(loadings) == 'TRUE') {loadings <- loadings$loadings}

if (ncol(loadings) == 1) {
cat("\n\nWARNING: There was only one factor, rotation not performed\n") }

if (ncol(loadings) > 1) {

b <- as.matrix(loadings)
n <- nrow(loadings)
nf <- ncol(loadings)
hjsq <- diag(loadings %*% t(loadings))   # communalities
hj <- sqrt(hjsq)
bh <- loadings / (hj %*% matrix(1,1,nf))

Vtemp <- n * sum(bh^4) - sum( colSums(bh^2)^2 )
V0 <- Vtemp

for (it in 1:30) { # Never seems to need very many iterations
for (i in 1:nf-1) { # Program cycles through 2 factors
  jl <- i+1    # at a time
  for (j in jl:nf) {
      xj <- loadings[,i]/hj   # notation here closely
      yj <- loadings[,j]/hj   # follows harman
      uj <- xj*xj-yj*yj
      vj <- 2*xj*yj
      A <- sum(uj)
      B <- sum(vj)
      C <- t(uj) %*% uj - t(vj) %*% vj
      D <- 2*t(uj)%*%vj
      num <- D-2*A*B/n
      den <- C-(A^2-B^2)/n
      tan4p <- num/den
      phi <- atan2(num,den)/4
      angle <- phi*180/pi
      if (abs(phi)>.00001) {
          Xj <- cos(phi)*xj+sin(phi)*yj
          Yj <- -sin(phi)*xj+cos(phi)*yj
          bj1 <- Xj*hj
          bj2 <- Yj*hj
          b[,i] <- bj1
          b[,j] <- bj2
          loadings[,i] <- b[,i]
          loadings[,j] <- b[,j]
}}}

loadings <- b
bh <- loadings / (hj %*% matrix(1,1,nf))
Vtemp <- n * sum(bh^4) - sum( colSums(bh^2)^2 )
V <- Vtemp
if (abs(V-V0) < .0001) {break
} else {V0 <- V}
}

colnames(loadings) <- cbind(  (matrix( ("Factor"),1,ncol(loadings) )))

if (display == 'yes') {
# cat("\nUnrotated Loadings:")
# print(b)
cat("\n\nVarimax Rotated Loadings:\n\n")
print(round(loadings,2));cat("\n\n")
}
}

#varimaxOutput <- list( loadings=loadings  )
varimaxOutput <-  loadings  

return(invisible(varimaxOutput))

}
