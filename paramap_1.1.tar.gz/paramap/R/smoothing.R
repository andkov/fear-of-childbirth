

smoothing <- function(rpolys){

cat("\nOne or more negative eigenvalues exist in the matrix of")
cat("\npolychoric correlations. The matrix was therefore smoothed")
cat("\nby adding a ridge to the diagonal (see Werner & Wothke, 1993, p. 261).\n\n")

# ridge approach = adding a constant to the diagonal so that
# the smallest eval is > 0; Wothke 1993 p 261, and SAS Proc CALIS p 269
constant  = .25;
increment = .25;
for (lupe in 1:1000) {
rpolys2 = rpolys + diag(constant*diag(cbind(rpolys)))
if ((min(eigen(rpolys2) $value)) > 0 & (min(eigen(rpolys2) $value)) < .001) {break}
if ((min(eigen(rpolys2) $value)) <= 0) { constant = constant + increment}
if ((min(eigen(rpolys2) $value)) >  0) { increment = increment / 2; constant = constant - increment}
}

return(rpolys2)

}
