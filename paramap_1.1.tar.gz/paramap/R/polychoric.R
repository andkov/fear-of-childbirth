

polychoric <- function (data){

if(all( (data - trunc(data)) == 0) == FALSE)  
{cat("\nThe data matrix does not appear to consist of whole numbers and is therefore not appropriate for the computation of polychoric correlations.")
cat("\nConsider stopping the program.\n\n")}

cnoms <- colnames(data) # get colnames

rpolys <- matrix(-9999,ncol(data),ncol(data))
for (i in 1:(ncol(data)-1) ) {
for (j in (i+1):ncol(data) ) {
rpolys[i,j] <- polychor(data[,i], data[,j],  ML=FALSE, std.err=FALSE, .9999) 
rpolys[j,i] <- rpolys[i,j]
}}

diag(rpolys) <- 1

if ( min(eigen(rpolys) $values) < 0 ) { rpolys <- smoothing(rpolys) } 

colnames(rpolys) <- cnoms
rownames(rpolys) <- cnoms

return(invisible(rpolys))

}
